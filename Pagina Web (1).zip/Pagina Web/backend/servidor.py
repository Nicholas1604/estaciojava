from flask import Flask, request, jsonify, render_template, redirect, url_for
import datetime
import uuid

from flask_cors import CORS

app = Flask(__name__)
CORS(app)



# Função para armazenar pedidos
def armazenar_pedido(pedido):
    pedido_id = str(uuid.uuid4())  # Gera um UUID para cada pedido
    with open('pedidos.txt', 'a') as file:
        file.write(f"{pedido_id},{pedido}\n")  # Assegure que a estrutura esteja correta e completa
    return pedido_id

    
# Função para ler os pedidos
def ler_pedidos():
    with open('pedidos.txt', 'r') as file:
        pedidos = [line.strip() for line in file if line.strip()]
    return pedidos


@app.route('/pedido', methods=['POST'])
def pedido():
    nome = request.form['nome']
    endereco = request.form['endereco']
    pizza = request.form['pizza']
    quantidade = request.form['quantidade']
    timestamp = datetime.datetime.now().isoformat()
    pedido_info = f"{timestamp},{nome},{endereco},{pizza},{quantidade},pendente"
    pedido_id = armazenar_pedido(pedido_info)
    return jsonify({'message': 'Pedido recebido com sucesso!', 'pedido_id': pedido_id}), 200

@app.route('/')
def lista_pedidos():
    pedidos = ler_pedidos()
    return render_template('menu.html')

@app.route('/prontos')
def mostrar_prontos():
    pedidos = ler_pedidos()
    prontos = [pedido for pedido in pedidos if 'pronto' in pedido.split(',')[6]]
    return render_template('prontos.html', orders=prontos)


@app.route('/pendentes')
def mostrar_pendentes():
    pedidos = ler_pedidos()
    pendentes = [pedido for pedido in pedidos if 'pendente' in pedido.split(',')[6]]
    print("Pedidos Pendentes:", pendentes)  # Debug para ver o que está sendo passado
    return render_template('pendentes.html', orders=pendentes)



@app.route('/total-vendas')
def total_vendas():
    pedidos = ler_pedidos()
    prontos = [pedido for pedido in pedidos if 'pronto' in pedido.split(',')[6]]
    pendentes = [pedido for pedido in pedidos if 'pendente' in pedido.split(',')[6]]
    
    total_prontos = sum(int(p.split(',')[4]) * int(p.split(',')[5]) for p in prontos)
    total_pendentes = sum(int(p.split(',')[4]) * int(p.split(',')[5]) for p in pendentes)
    
    # Passando prontos e pendentes separadamente para exibição detalhada
    return render_template('total_vendas.html', 
                           total_prontos=total_prontos, 
                           total_pendentes=total_pendentes,
                           prontos=prontos,
                           pendentes=pendentes)


@app.route('/faturamento')
def faturamento():
    pedidos = ler_pedidos()
    prontos = [pedido for pedido in pedidos if 'pronto' in pedido.split(',')[6]]
    total = sum(int(pedido.split(',')[4]) * int(pedido.split(',')[5]) for pedido in prontos if len(pedido.split(',')) > 5)
    return f"Total Faturado Hoje: R${total}"



@app.route('/marcar-pronto/<pedido_id>', methods=['POST'])
def marcar_pronto(pedido_id):
    pedidos = ler_pedidos()
    atualizado = False
    for i in range(len(pedidos)):
        id, data = pedidos[i].split(',', 1)
        partes = data.split(',')
        if id == pedido_id and 'pendente' in partes[5]:  # Ajustando índice para 5 porque já separamos o ID
            partes[5] = 'pronto'
            pedidos[i] = f"{id},{','.join(partes)}"
            atualizado = True
            break
    if atualizado:
        with open('pedidos.txt', 'w') as file:
            for pedido in pedidos:
                file.write(f"{pedido}\n")
        return jsonify({'message': 'Pedido marcado como pronto!'}), 200
    else:
        return jsonify({'message': 'Pedido não encontrado ou já pronto'}), 404


   

#DISPONIBILIZA DADOS PARA A ETAPA 2
@app.route('/data')
def serve_data():
    pedidos = []
    try:
        with open('pedidos.txt', 'r') as file:
            for line in file:
                uuid, timestamp, nome, endereco, preco, quantidade, status = line.strip().split(',')
                pedidos.append({
                    'uuid': uuid,
                    'timestamp': timestamp,
                    'nome': nome,
                    'endereco': endereco,
                    'preco': int(preco),
                    'quantidade': int(quantidade),
                    'status': status
                })
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
    return jsonify(pedidos)



#DEBUGANDO
@app.route('/debug')
def debug_pedidos():
    pedidos = ler_pedidos()
    for pedido in pedidos:
        partes = pedido.split(',')
        print(partes)  # Veja como os dados estão sendo divididos
    return "Verifique os logs para detalhes"


if __name__ == '__main__':
    app.run(debug=True)
